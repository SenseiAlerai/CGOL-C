#include <stdio.h>
#include <stdlib.h>

int main(){

   int grid[6][6];

   int a, b;
   for(a=0; a<6; a++) {
      for(b=0;b<6;b++) {
         printf("Enter the values of grid[%d][%d]:", a, b);
         fflush(stdout);
         scanf("%d", &grid[a][b]);
      }

   }
   //Display elements of Array
   printf("Present Generation:\n");
   for(a=0; a<6; a++) {
      for(b=0;b<6;b++) {

         printf("%d", grid[a][b]);
      }

      printf("\n");
   }


  void fun(int n, int m, int grid[n][m]);
  const int n=6,m=6;

  fun(n,m,grid);

  return 0;
}

void fun(int n,int m, int grid[n][m]){

int array[6][6];
int i,j;
int aliveNeighbours = 0;
for(i=0; i<6; i++){
for(j=0;j<6;j++){
aliveNeighbours = 0;
int x,y;

for (x = -1; x <= 1; x++){
for (y = -1; y <= 1; y++){

if (grid[i+x][j+y]==1){
aliveNeighbours++;


                    }



                   }

}

               aliveNeighbours = aliveNeighbours - grid[i][j];


               if (aliveNeighbours < 2)
                                   array[i][j] = 0;

                               // Cell dies due to over population
                               else if (aliveNeighbours > 3)
                                   array[i][j] = 0;

                               // A new cell is born
                               else if (aliveNeighbours == 3)
                                   array[i][j] = 1;

                               // Remains the same
                               else if (aliveNeighbours==2){

                                if(grid[i][j]==1){
                                array[i][j]=1;
                                }
                                else
                                array[i][j]=0;

                               }

}
}

int a,b;
printf("\n");
printf("Second Generation:\n");
for(a=0; a<6; a++) {
     for(b=0;b<6;b++) {

        printf("%d", array[a][b]);
     }
     printf("\n");
  }


}
